<?php

    echo $_POST['usuario'];
    echo "<br />";
    echo $_POST['email'];
    echo "<br />";
    echo $_POST['senha'];

?>